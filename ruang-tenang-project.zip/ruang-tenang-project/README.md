# Ruang Tenang

Website ketenangan & jurnal perasaan — siap untuk di-deploy sebagai website mandiri.

## Menjalankan di komputer sendiri

Butuh [Node.js](https://nodejs.org) versi 18 ke atas.

```bash
npm install
npm run dev
```

Buka alamat yang muncul di terminal (biasanya `http://localhost:5173`).

## Build untuk produksi

```bash
npm run build
```

Hasilnya akan muncul di folder `dist/` — folder inilah yang di-upload/deploy.

## Deploy ke Vercel (paling mudah)

1. Buat akun di [vercel.com](https://vercel.com) (bisa login pakai GitHub).
2. Upload folder ini ke repository GitHub baru, ATAU pakai Vercel CLI:
   ```bash
   npm install -g vercel
   vercel
   ```
3. Ikuti instruksi di layar — Vercel otomatis mendeteksi ini project Vite dan akan build sendiri.
4. Setelah selesai, dapat link `nama-project.vercel.app`. Domain sendiri bisa disambungkan lewat menu Settings → Domains.

## Deploy ke Netlify (alternatif)

1. Jalankan `npm run build` di komputer sendiri dulu.
2. Buka [app.netlify.com/drop](https://app.netlify.com/drop).
3. Seret (drag) folder `dist/` ke halaman tersebut. Selesai, langsung online.

## Catatan tentang jurnal

Jurnal perasaan disimpan di `localStorage` browser pengunjung — artinya:
- Data tersimpan otomatis dan tetap ada walau browser ditutup.
- Data **hanya tersimpan di perangkat/browser masing-masing pengunjung**, tidak tersinkron antar perangkat, dan tidak dikirim ke server manapun (privat sepenuhnya).
- Kalau nanti mau jurnal bisa diakses dari HP dan laptop secara bersamaan (butuh login), itu perlu backend + database tambahan — bukan bagian dari setup ini.

## Struktur project

```
├── index.html          # Halaman HTML utama
├── src/
│   ├── main.jsx         # Entry point React
│   └── RuangTenang.jsx  # Seluruh komponen & styling website
├── package.json
└── vite.config.js
```
